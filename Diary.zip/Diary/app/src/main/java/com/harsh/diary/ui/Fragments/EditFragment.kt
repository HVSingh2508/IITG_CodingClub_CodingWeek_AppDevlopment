package com.harsh.diary.ui.Fragments

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.harsh.diary.Model.Notes
import com.harsh.diary.R
import com.harsh.diary.databinding.FragmentEditBinding
import com.harsh.project.ViewModel.NotesViewModel


class EditFragment : Fragment() {

    val not by navArgs<EditFragmentArgs>()

    lateinit var binding: FragmentEditBinding

    val viewModel: NotesViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        binding = FragmentEditBinding.inflate(layoutInflater,container, false)

        binding.EtitleField.setText(not.data.title)
        binding.EsubTitleField.setText(not.data.subtitle)
        binding.EnotesField.setText(not.data.notes)


        binding.editBtn.setOnClickListener{
            updateNotes(it)
        }

        binding.deleteBtn.setOnClickListener{
            deleteNotes(it)
        }

        return binding.root
    }

    private fun deleteNotes(it: View?) {
        val bottonSheet : Dialog = Dialog(requireContext())

        bottonSheet.setContentView(R.layout.dialog_delete)

        // TRANSPARENT BACKGROUND OF DELETE DIALOG
        bottonSheet.getWindow()?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));


        bottonSheet.show()
        val yes = bottonSheet.findViewById<TextView>(R.id.delYesBtn)
        val no = bottonSheet.findViewById<TextView>(R.id.delNoBtn)

        yes?.setOnClickListener{
            viewModel.deleteNotes(not.data.id!!)
            bottonSheet.dismiss()

        }
        no?.setOnClickListener{
            bottonSheet.dismiss()
        }

        outF(it!!)

    }

    private fun outF(it : View) {
        Navigation.findNavController(it!!).navigate(R.id.action_editFragment2_to_homeFragment2)
    }

    private fun updateNotes(it: View?) {
        val title1 = binding.EtitleField.text.toString()
        val subtitle1 = binding.EsubTitleField.text.toString()
        val notes1 = binding.EnotesField.text.toString()



        if(!(title1 == "")) {

            val data = Notes(id = not.data.id, title = title1, subtitle = subtitle1, notes = notes1)
            viewModel.updateNotes(data)
            Toast.makeText(requireContext(),": Entry Updated :", Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(requireContext(),": EMPTY TITLE DETECTED : Try Again :", Toast.LENGTH_SHORT).show()
        }

        Navigation.findNavController(it!!).navigate(R.id.action_editFragment2_to_homeFragment2)

    }

}