package com.harsh.diary.ui.Adaptor

import android.content.Context
import android.view.LayoutInflater
import com.harsh.diary.Model.Notes
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.harsh.diary.R
import com.harsh.diary.databinding.ItemNotesBinding
import com.harsh.diary.ui.Fragments.HomeFragment
import com.harsh.diary.ui.Fragments.HomeFragmentDirections

class NotesAdaptor(val requireContext: Context, val notesList: List<Notes>) : RecyclerView.Adapter<NotesAdaptor.notesViewHolder>() {

    class notesViewHolder(val binding: ItemNotesBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): notesViewHolder {
        return notesViewHolder((ItemNotesBinding.inflate(LayoutInflater.from(parent.context),parent,false)))
    }

    override fun onBindViewHolder(holder: notesViewHolder, position: Int) {
       val data = notesList[position]
        holder.binding.titleDisplay.text = data.title.toString()
        holder.binding.subtitleDisplay.text = data.subtitle.toString()
        holder.binding.notesDisplay.text = data.notes.toString()


        holder.binding.root.setOnClickListener{
            val action = HomeFragmentDirections.actionHomeFragment2ToEditFragment2(data)
            Navigation.findNavController(it).navigate(action)

        }

    }

    override fun getItemCount() = notesList.size
}