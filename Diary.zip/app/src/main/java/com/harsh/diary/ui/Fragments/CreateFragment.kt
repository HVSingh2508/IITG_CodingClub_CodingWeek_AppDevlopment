package com.harsh.diary.ui.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.harsh.diary.Model.Notes
import com.harsh.diary.R
import com.harsh.diary.databinding.FragmentCreateBinding
import com.harsh.project.ViewModel.NotesViewModel
import android.view.MenuItem;
import androidx.activity.OnBackPressedCallback
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.fragment.findNavController

class CreateFragment : Fragment() {

    lateinit var binding : FragmentCreateBinding

    val viewModel : NotesViewModel  by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        binding = FragmentCreateBinding.inflate(layoutInflater, container, false)

        binding.saveBtn.setOnClickListener{
            creataNotes(it)
        }



        return binding.root
    }

    private fun creataNotes(it : View) {
        val title1 = binding.CtitleField.text.toString()
        val subtitle1 = binding.CsubTitleField.text.toString()
        val notes1 = binding.CnotesField.text.toString()
        if(!(title1 == "")) {
            val data = Notes(null, title = title1, subtitle = subtitle1, notes = notes1)
            viewModel.addNotes(data)
            Toast.makeText(requireContext(),": Entry Created :",Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(requireContext(),": EMPTY TITLE DETECTED : Try Again :",Toast.LENGTH_SHORT).show()
        }

        Navigation.findNavController(it!!).navigate(R.id.action_createFragment2_to_homeFragment2)

    }
}