package com.harsh.diary.ui.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.harsh.diary.R
import com.harsh.diary.databinding.FragmentHomeBinding
import com.harsh.diary.ui.Adaptor.NotesAdaptor
import com.harsh.project.ViewModel.NotesViewModel

class HomeFragment : Fragment() {

    lateinit var binding: FragmentHomeBinding
    val viewModel: NotesViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment


        binding = FragmentHomeBinding.inflate(layoutInflater,container,false)

        viewModel.getNotes().observe(viewLifecycleOwner,{notesList ->

            //binding.rcvAllNotes.layoutManager = GridLayoutManager(requireContext(),2)

            binding.rcvAllNotes.layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)

            binding.rcvAllNotes.adapter = NotesAdaptor(requireContext(),notesList)

        })

        binding.addBtn.setOnClickListener{
            Navigation.findNavController(it).navigate(R.id.action_homeFragment2_to_createFragment2)
        }

        return binding.root
    }
}